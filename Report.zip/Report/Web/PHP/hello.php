#!/usr/bin/php
<?php
echo "hello\n";
