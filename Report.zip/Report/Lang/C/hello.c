#include <stdio.h>

int main(){
	printf("Hello New World");
	return 0;
}
